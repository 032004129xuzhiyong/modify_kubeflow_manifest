Please note: This component is **unmaintained and out-of-date**.

The latest tektoncd distribution is now maintained as part of the `kfp-tekton` component release. To deploy tektoncd standalone with kustomize, please use the latest tektoncd kustomization.yaml over [here](/apps/kfp-tekton/upstream/third-party/tekton/base/kustomization.yaml).

Any components that fails to meet [contrib requirements](https://github.com/kubeflow/manifests/blob/master/proposals/20220926-contrib-component-guidelines.md#component-requirements)
 by the next Kubeflow release ([1.7](https://github.com/kubeflow/community/tree/master/releases/release-1.7#timeline)) will be removed from the [`manifest`](https://github.com/kubeflow/manifests) repository.

Updates to the `/contrib` components can be found in the [tracking issue](https://github.com/kubeflow/manifests/issues/2311).