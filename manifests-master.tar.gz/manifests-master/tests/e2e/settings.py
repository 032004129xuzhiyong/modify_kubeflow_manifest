NAMESPACE = "kubeflow-user-example-com"
TIMEOUT = 600

PIPELINE_NAME = "mnist-e2e"
EXPERIMENT_NAME = "mnist-e2e"
TFJOB_NAME = "mnist-e2e"
ISVC_NAME = "mnist-e2e"

TRAINING_STEPS = "1"
